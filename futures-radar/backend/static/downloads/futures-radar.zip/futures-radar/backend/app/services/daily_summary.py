"""品种日度汇总研判：每天一次调 DeepSeek，把该品种近 N 天资讯综合判断。

产出：
  - direction / sentiment_llm / confidence / horizon
  - factor_weights（LLM 自己评估各因子权重，覆盖静态权重做"专家修正"）
  - summary（一句话，Dashboard 卡片下方展示）
  - reasoning / evidence / article_count
"""
from __future__ import annotations

import json
import time
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import httpx
from sqlalchemy import desc, select

from ..config import settings
from ..db import SessionLocal
from ..models import Analysis, DailySummary, RawDoc, Score, Variety

CST = ZoneInfo("Asia/Shanghai")
FACTOR_NAMES = ["供给", "需求", "库存", "成本", "政策", "天气", "宏观", "资金/结构"]

SYSTEM_PROMPT = """你是一名专注中国期货市场（郑商所品种）的资深研究员。
现在需要你对某一品种过去几天的资讯进行"汇总研判"，给出综合结论。

要求：
1. 只依据提供的资讯列表，不得引入外部数据。
2. 给 direction（bullish/bearish/neutral）和 sentiment_llm（-100~100 情绪分数，可小数）。
3. 给 factor_weights：一个对象，只含供给/需求/库存/成本/政策/天气/宏观/资金/结构 这 8 个因子的相对权重（0-100，整数）。
4. summary：一句话结论，40 字以内，用于卡片下方直接展示。
5. evidence：从资讯标题里挑最多 3 个最关键的标题（原样截取）。
6. horizon：intraday / short / medium / long。
7. confidence：0-1。
8. 输出严格 JSON，不要 Markdown，不要额外说明。

JSON 结构：
{
  "direction": "bullish",
  "sentiment_llm": 35.5,
  "factor_weights": {"供给": 80, "需求": 20, "库存": 0, "成本": 0, "政策": 0, "天气": 0, "宏观": 0, "资金/结构": 0},
  "primary_factor": "供给",
  "summary": "巴西增产+国内库存累积，短期白糖承压",
  "reasoning": "近 7 天资讯显示…",
  "evidence": ["巴西中南部糖产量同比增加 8%", "广西部分糖厂开榨推迟"],
  "horizon": "short",
  "confidence": 0.75
}"""


def _build_user_prompt(variety: Variety, titles: list[str], analyses: list[Analysis]) -> str:
    factors_desc = "、".join(
        f"{vf.factor.name} 权重{vf.weight:.1f}" for vf in variety.factors
    ) if variety.factors else "默认"
    rows = []
    for idx, (t, a) in enumerate(zip(titles, analyses), 1):
        rows.append(f"{idx}. 【{a.factor or '—'}】dir={a.direction or '—'} strength={a.strength or '—'} conf={a.confidence or '—'} | {t}")
    body = "\n".join(rows)
    return f"""【品种】{variety.code} {variety.name}
【品种专属因子权重（静态）】{factors_desc}
【资讯列表（近 {len(titles)} 条）】
{body}

请综合以上资讯，输出汇总研判 JSON。"""


async def _call_llm(system: str, user: str) -> tuple[dict, int, str]:
    """返回 (parsed_json, latency_ms, model)。未配置 key 或失败时抛异常。"""
    if not settings.deepseek_api_key:
        raise RuntimeError("未配置 DEEPSEEK_API_KEY")
    started = time.perf_counter()
    payload = {
        "model": settings.deepseek_model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0.2,
        "max_tokens": 1400,
        "response_format": {"type": "json_object"},
    }
    headers = {
        "Authorization": f"Bearer {settings.deepseek_api_key}",
        "Content-Type": "application/json",
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            f"{settings.deepseek_base_url.rstrip('/')}/chat/completions",
            headers=headers, json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
    raw = data["choices"][0]["message"]["content"]
    parsed = json.loads(raw)
    latency = int((time.perf_counter() - started) * 1000)
    return parsed, latency, data.get("model", settings.deepseek_model)


def _norm_summary(text: str, max_len: int = 80) -> str:
    text = (text or "").strip()
    if len(text) > max_len:
        text = text[:max_len - 1] + "…"
    return text


def _parse_safe(parsed: dict) -> dict:
    """把 LLM 返回的 JSON 规整成 DailySummary 字段能吃的结构。"""
    direction = parsed.get("direction", "neutral")
    if direction not in ("bullish", "bearish", "neutral"):
        direction = "neutral"
    try:
        sentiment_llm = float(parsed.get("sentiment_llm", 0))
        sentiment_llm = max(-100.0, min(100.0, sentiment_llm))
    except (TypeError, ValueError):
        sentiment_llm = 0.0
    try:
        confidence = max(0.0, min(1.0, float(parsed.get("confidence", 0.5))))
    except (TypeError, ValueError):
        confidence = 0.5
    horizon = parsed.get("horizon", "short")
    if horizon not in ("intraday", "short", "medium", "long"):
        horizon = "short"
    factor_weights = {}
    for fname in FACTOR_NAMES:
        try:
            v = int(parsed.get("factor_weights", {}).get(fname, 0))
            factor_weights[fname] = max(0, min(100, v))
        except (TypeError, ValueError):
            factor_weights[fname] = 0
    # 只保留 >0 的
    factor_weights = {k: v for k, v in factor_weights.items() if v > 0}
    evidence = []
    for t in parsed.get("evidence", [])[:3]:
        if isinstance(t, str) and t.strip():
            evidence.append(t.strip()[:120])
    return {
        "direction": direction,
        "sentiment_llm": round(sentiment_llm, 1),
        "confidence": round(confidence, 2),
        "horizon": horizon,
        "primary_factor": str(parsed.get("primary_factor", ""))[:32],
        "factor_weights": factor_weights,
        "summary": _norm_summary(str(parsed.get("summary", "")), 80),
        "reasoning": _norm_summary(str(parsed.get("reasoning", "")), 300),
        "evidence": evidence,
    }


async def summarize_variety(code: str, days: int = 7) -> DailySummary | None:
    """对单个品种做一次日度汇总研判，upsert 到 DailySummary。"""
    with SessionLocal() as db:
        variety = db.execute(select(Variety).where(Variety.code == code, Variety.is_active.is_(True))).scalar_one_or_none()
        if variety is None:
            return None
        cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=days)
        docs = db.execute(
            select(RawDoc).join(Score, Score.doc_id == RawDoc.id)
            .where(Score.variety_code == code, RawDoc.first_seen_at >= cutoff)
            .order_by(desc(Score.importance))
            .limit(40)
        ).scalars().all()
        if not docs:
            return None
        titles = []
        analyses = []
        for d in docs:
            a = db.execute(select(Analysis).where(Analysis.doc_id == d.id)).scalars().first()
            if a:
                titles.append(d.title)
                analyses.append(a)
        if not analyses:
            return None
        # 尝试 LLM 汇总
        try:
            parsed, latency, model = await _call_llm(
                SYSTEM_PROMPT, _build_user_prompt(variety, titles, analyses),
            )
            norm = _parse_safe(parsed)
            status = "ok"
            err = ""
        except Exception as exc:  # noqa: BLE001
            # 回退：基于现有 Score 做规则汇总
            scores = db.execute(
                select(Score).where(Score.variety_code == code, Score.doc_id.in_([d.id for d in docs]))
            ).scalars().all()
            num = sum(s.score * s.importance for s in scores)
            den = sum(s.importance for s in scores)
            sent = (num / den * 100) if den else 0.0
            sent = round(max(-100.0, min(100.0, sent)), 1)
            bull = sum(1 for s in scores if s.direction == "bullish")
            bear = sum(1 for s in scores if s.direction == "bearish")
            factor_counts: dict[str, float] = {}
            for s in scores:
                w = abs(s.score)
                if w and s.factor:
                    factor_counts[s.factor] = factor_counts.get(s.factor, 0) + w
            norm = {
                "direction": "bullish" if sent > 15 else ("bearish" if sent < -15 else "neutral"),
                "sentiment_llm": sent,
                "confidence": round(min(1.0, 0.3 + len(scores) * 0.05), 2),
                "horizon": "short",
                "primary_factor": max(factor_counts, key=factor_counts.get) if factor_counts else "",
                "factor_weights": {k: round(v / max(factor_counts.values()) * 100) for k, v in factor_counts.items()} if factor_counts else {},
                "summary": f"规则汇总：近{days}天 bull {bull} / bear {bear}，情绪 {sent:+.1f}%",
                "reasoning": "",
                "evidence": [],
            }
            latency = 0
            model = "rule-fallback"
            status = "ok"
            err = str(exc)[:200]

        # upsert
        local_date = date.today()
        row = db.execute(
            select(DailySummary).where(
                DailySummary.variety_code == code, DailySummary.date == local_date.isoformat()
            )
        ).scalar_one_or_none()
        if row is None:
            row = DailySummary(
                variety_code=code, date=local_date.isoformat(), model=model,
                status=status, article_count=len(analyses), latency_ms=latency, error=err,
                **norm,
            )
            db.add(row)
        else:
            row.model = model; row.status = status
            row.article_count = len(analyses); row.latency_ms = latency; row.error = err
            for k, v in norm.items():
                setattr(row, k, v)
        db.commit()
        return row


async def summarize_all_active(days: int = 7) -> list[str]:
    """对所有活跃品种跑一次汇总。失败不阻塞下一个。"""
    with SessionLocal() as db:
        codes = [c for (c,) in db.execute(select(Variety.code).where(Variety.is_active.is_(True))).all()]
    results = []
    for code in codes:
        try:
            r = await summarize_variety(code, days=days)
            if r:
                results.append(code)
                print(f"[daily-summary] {code} {r.direction} sent={r.sentiment_llm:+.1f}% n={r.article_count}")
            else:
                print(f"[daily-summary] {code} 跳过（无资讯）")
        except Exception as exc:  # noqa: BLE001
            print(f"[daily-summary] {code} 失败：{exc}")
    return results


def get_latest_summary(code: str) -> DailySummary | None:
    """取某品种最近一次（不论哪一天）的汇总，供 Dashboard 卡片展示。"""
    with SessionLocal() as db:
        return db.execute(
            select(DailySummary).where(DailySummary.variety_code == code)
            .order_by(desc(DailySummary.created_at)).limit(1)
        ).scalar_one_or_none()
