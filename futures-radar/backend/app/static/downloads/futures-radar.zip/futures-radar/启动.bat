@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0backend"

where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 没有检测到 Python，请先安装 Python 3.10 或更高版本，并勾选 Add to PATH。
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/4] 首次运行，创建运行环境...
  python -m venv .venv
)

echo [2/4] 检查依赖...
".venv\Scripts\python.exe" -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo [错误] 依赖安装失败，请检查网络后重试。
  pause
  exit /b 1
)

echo [3/4] 下载 Cloudflare Tunnel（用于公网访问，手机随时可用）...
set "CF_DIR=%~dp0cloudflared"
if not exist "%CF_DIR%\cloudflared.exe" (
  mkdir "%CF_DIR%" 2>nul
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile '%CF_DIR%\cloudflared.exe'" 2>nul
  if not exist "%CF_DIR%\cloudflared.exe" (
    echo [提示] cloudflared 下载失败，将跳过公网隧道。仅本机/局域网可用。
  )
)

echo [4/4] 启动服务...
start "期货雷达后端" cmd /k ""%cd%\.venv\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8000"
timeout /t 5 >nul

echo.
echo ============================================
echo   期货雷达已启动
echo ============================================
echo.
echo 本机访问:  http://127.0.0.1:8000
start "" http://127.0.0.1:8000

for /f %%i in ('powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 ^| Where-Object {$_.IPAddress -notlike '127.*'} ^| Select-Object -First 1).IPAddress"') do set LANIP=%%i
if defined LANIP (
  echo 手机/Wi-Fi: http://%LANIP%:8000
)

if exist "%CF_DIR%\cloudflared.exe" (
  echo.
  echo --- 正在启动公网隧道（首次可能需要 10-20 秒） ---
  echo 手机/外网公网地址将在下一行显示：
  start "Cloudflare Tunnel" cmd /c ""%CF_DIR%\cloudflared.exe" tunnel --url http://127.0.0.1:8000 --no-autoupdate 2>&1 | findstr /i "https://.*trycloudflare.com""
)

echo.
echo ============================================
echo  关闭服务：关掉「期货雷达后端」窗口即可。
echo  如果手机打不开：
echo   - 同一 Wi-Fi 访问不了 → 允许 Windows 防火墙 8000 端口
echo   - 公网地址打不开 → 等 10-20 秒，或检查 Cloudflare Tunnel 窗口
echo ============================================
pause
