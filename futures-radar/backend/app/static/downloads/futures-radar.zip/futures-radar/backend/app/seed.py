"""初始化数据：品种、因子、品种-因子权重、数据源、示例资讯。"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from .config import settings
from .db import Base, SessionLocal, engine
from .models import Analysis, Factor, RawDoc, Score, Source, Variety, VarietyFactor
from .services.scoring import compute_score

FACTORS = [
    ("供给", "供给", "产量、开工、检修、进口等供应端变化", "#2563eb"),
    ("需求", "需求", "下游开工、消费、订单、出口需求", "#059669"),
    ("库存", "库存", "港口/厂库/社会库存与仓单", "#d97706"),
    ("成本", "成本", "原油、煤炭、天然气、电力等成本项", "#7c3aed"),
    ("政策", "政策", "配额、关税、收储抛储、环保与产业政策", "#dc2626"),
    ("天气", "天气", "产区天气与灾害对产量/运输的影响", "#0891b2"),
    ("宏观", "宏观", "利率、汇率、通胀与风险偏好", "#475569"),
    ("资金/结构", "资金", "持仓、基差、跨期与资金流向", "#db2777"),
]

ACTIVE_VARIETIES = [
    {
        "code": "SR", "name": "白糖", "sector": "软商品/农产品", "sort_order": 1,
        "aliases": ["白糖", "郑糖", "食糖"],
        "keywords": ["白糖", "食糖", "原糖", "甘蔗", "甜菜", "糖厂", "广西糖", "云南糖", "内蒙糖",
                     "配额", "抛储", "收储", "淀粉糖", "含糖", "巴西糖", "印度糖", "泰国糖"],
        "description": "郑商所白糖期货，核心看广西/云南/内蒙产量、巴西印度泰国出口、进口政策与消费。",
        "factors": {"天气": 0.9, "供给": 0.9, "成本": 0.7, "政策": 0.7, "需求": 0.6, "库存": 0.5, "宏观": 0.3},
        "factor_keywords": {
            "供给": ["广西", "云南", "开榨", "收榨", "甘蔗", "甜菜", "糖厂", "原糖", "巴西", "印度", "泰国"],
            "需求": ["含糖", "饮料", "食品", "消费", "淀粉糖"],
            "库存": ["仓单", "食糖库存"],
            "成本": ["原糖价格", "运费"],
            "政策": ["配额", "关税", "抛储", "收储", "打击走私"],
        },
    },
    {
        "code": "CF", "name": "棉花", "sector": "软商品/农产品", "sort_order": 2,
        "aliases": ["棉花", "郑棉", "皮棉"],
        "keywords": ["棉花", "籽棉", "皮棉", "新疆棉", "植棉", "棉花种植", "USDA", "滑准税", "配额",
                     "纺企", "棉纱", "服装出口", "轮换", "仓单", "轧花厂"],
        "description": "郑商所棉花期货，核心看新疆产量与收购价、USDA 报告、进口配额、纺织需求。",
        "factors": {"供给": 0.9, "需求": 0.8, "政策": 0.8, "天气": 0.7, "库存": 0.5, "成本": 0.4, "宏观": 0.4},
        "factor_keywords": {
            "供给": ["新疆", "籽棉", "皮棉", "植棉面积", "轧花厂", "USDA"],
            "需求": ["纺企", "棉纱", "服装出口", "开机率", "订单"],
            "库存": ["仓单", "棉花库存"],
            "政策": ["滑准税", "配额", "轮换", "收储"],
        },
    },
    {
        "code": "MA", "name": "甲醇", "sector": "能源化工", "sort_order": 3,
        "aliases": ["甲醇", "郑醇", "MTO"],
        "keywords": ["甲醇", "MTO", "煤制甲醇", "天然气制甲醇", "伊朗", "甲醇进口", "港口库存",
                     "烯烃", "甲醛", "二甲醚", "醋酸", "限气"],
        "description": "郑商所甲醇期货，核心看煤炭/天然气成本、伊朗进口、MTO 开工、港口库存。",
        "factors": {"供给": 0.9, "成本": 0.85, "库存": 0.8, "需求": 0.7, "政策": 0.5, "天气": 0.5, "宏观": 0.4},
        "factor_keywords": {
            "供给": ["装置", "伊朗", "进口", "开工", "检修", "限气", "天然气"],
            "需求": ["MTO", "烯烃", "甲醛", "二甲醚", "醋酸"],
            "库存": ["港口库存", "甲醇库存"],
            "成本": ["煤炭", "煤价", "天然气"],
        },
    },
    {
        "code": "SA", "name": "纯碱", "sector": "能源化工", "sort_order": 4,
        "aliases": ["纯碱", "苏打"],
        "keywords": ["纯碱", "天然碱", "联碱", "氨碱", "光伏玻璃", "浮法玻璃", "重碱", "轻碱",
                     "纯碱库存", "碱厂"],
        "description": "郑商所纯碱期货，核心看开工与检修、光伏/浮法玻璃需求、库存与环保限产。",
        "factors": {"供给": 0.9, "库存": 0.85, "需求": 0.8, "成本": 0.6, "政策": 0.5, "天气": 0.2, "宏观": 0.3},
        "factor_keywords": {
            "供给": ["碱厂", "开工率", "天然碱", "联碱", "氨碱", "检修", "装置"],
            "需求": ["光伏玻璃", "浮法玻璃", "重碱", "轻碱", "日熔量"],
            "库存": ["纯碱库存", "碱厂库存", "社会库存"],
            "政策": ["环保", "限产"],
        },
    },
    {
        "code": "FG", "name": "玻璃", "sector": "能源化工", "sort_order": 5,
        "aliases": ["玻璃", "浮法玻璃", "浮法"],
        "keywords": ["浮法玻璃", "玻璃", "冷修", "复产", "地产竣工", "深加工", "保交楼",
                     "玻璃库存", "窑炉", "产销率", "日熔量"],
        "description": "郑商所玻璃期货，核心看地产竣工、深加工订单、冷修复产、库存与成本。",
        "factors": {"需求": 0.9, "供给": 0.85, "库存": 0.8, "成本": 0.7, "政策": 0.6, "天气": 0.2, "宏观": 0.35},
        "factor_keywords": {
            "供给": ["冷修", "复产", "窑炉", "日熔量", "点火"],
            "需求": ["地产竣工", "深加工", "产销率", "保交楼", "订单"],
            "库存": ["玻璃库存", "沙河库存"],
            "成本": ["纯碱", "燃料", "天然气"],
            "政策": ["保交楼", "地产政策"],
        },
    },
]

PLACEHOLDER_VARIETIES = [
    ("CY", "棉纱", "软商品/农产品", ["棉纱", "进口纱"]),
    ("AP", "苹果", "软商品/农产品", ["苹果", "霜冻", "冷库"]),
    ("CJ", "红枣", "软商品/农产品", ["红枣", "新疆枣"]),
    ("PK", "花生", "软商品/农产品", ["花生", "油厂"]),
    ("OI", "菜籽油", "软商品/农产品", ["菜油", "菜籽"]),
    ("RM", "菜籽粕", "软商品/农产品", ["菜粕", "菜籽"]),
    ("RS", "油菜籽", "软商品/农产品", ["油菜籽", "菜籽"]),
    ("TA", "PTA", "能源化工", ["PTA", "PX", "聚酯"]),
    ("UR", "尿素", "能源化工", ["尿素", "复合肥", "印度招标"]),
    ("PF", "短纤", "能源化工", ["短纤", "涤纶"]),
    ("PR", "瓶片", "能源化工", ["瓶片", "聚酯"]),
    ("SH", "烧碱", "能源化工", ["烧碱", "氧化铝"]),
    ("PX", "对二甲苯", "能源化工", ["PX", "石脑油"]),
    ("SF", "硅铁", "铁合金", ["硅铁", "兰炭"]),
    ("SM", "锰硅", "铁合金", ["锰硅", "锰矿"]),
    ("ZC", "动力煤", "能源", ["动力煤", "秦皇岛"]),
    ("WH", "小麦", "农产品", ["小麦", "面粉"]),
]

SOURCES = [
    {"code": "czce_announce", "name": "郑商所公告通知", "type": "official", "level": "A",
     "url": "https://www.czce.com.cn/", "weight": 1.0, "interval_sec": 120, "priority": 1},
    {"code": "jin10_flash", "name": "金十快讯", "type": "news", "level": "C",
     "url": "https://www.jin10.com/", "weight": 0.65, "interval_sec": 60, "priority": 2},
    {"code": "sina_rss", "name": "新浪财经滚动", "type": "news", "level": "C",
     "url": "https://rss.sina.com.cn/roll/finance/hot_roll.xml", "weight": 0.6,
     "interval_sec": 900, "priority": 4},
    {"code": "sina_oil", "name": "新浪原油行情", "type": "market", "level": "F",
     "url": "https://finance.sina.com.cn", "weight": 1.0,
     "interval_sec": 60, "priority": 2},
    {"code": "fred_brent", "name": "FRED Brent 日线", "type": "market", "level": "F",
     "url": "https://fred.stlouisfed.org/", "weight": 1.0, "interval_sec": 21600, "priority": 6},
    {"code": "manual", "name": "手工录入", "type": "manual", "level": "E",
     "url": "", "weight": 0.8, "interval_sec": 0, "priority": 9},
]

SAMPLES = [
    {
        "title": "【示例】广西部分糖厂开榨推迟，短期供给偏紧",
        "content": "【示例】广西部分糖厂开榨时间较往年推迟 7-10 天，当前新糖上市量偏低，现货报价小幅上调。市场预计 11 月上中旬供给偏紧格局延续。",
        "varieties": ["SR"], "direction": "bullish", "strength": 3, "confidence": 0.72,
        "factor": "供给", "event_type": "减产", "horizon": "short",
        "summary": "广西开榨推迟，短期白糖供给偏紧，现货报价上调。",
        "evidence": "广西部分糖厂开榨时间较往年推迟 7-10 天，当前新糖上市量偏低",
        "reasoning": "开榨推迟压缩短期新糖供应，利多近月价格；中期仍需观察总产量。",
        "source_weight": 0.85, "hours_ago": 1,
    },
    {
        "title": "【示例】巴西中南部糖产量同比增加 8%",
        "content": "【示例】巴西甘蔗行业协会数据显示，中南部地区累计糖产量同比增加 8%，制糖比高于市场预期，原糖期货承压下挫。",
        "varieties": ["SR"], "direction": "bearish", "strength": 4, "confidence": 0.8,
        "factor": "供给", "event_type": "增产", "horizon": "medium",
        "summary": "巴西糖产量同比增 8%，全球供给宽松预期升温。",
        "evidence": "中南部地区累计糖产量同比增加 8%，制糖比高于市场预期",
        "reasoning": "主产国增产提升全球供应，利空原糖与郑糖远期。",
        "source_weight": 0.7, "hours_ago": 5,
    },
    {
        "title": "【示例】新疆籽棉收购价上调，轧花厂成本抬升",
        "content": "【示例】新疆北疆籽棉收购价较上周上调 0.15 元/公斤，轧花厂收购进度加快，皮棉成本抬升，部分贸易商挺价。",
        "varieties": ["CF"], "direction": "bullish", "strength": 2, "confidence": 0.65,
        "factor": "成本", "event_type": "其他", "horizon": "short",
        "summary": "籽棉收购价上调，棉花成本支撑增强。",
        "evidence": "籽棉收购价较上周上调 0.15 元/公斤",
        "reasoning": "收购成本上升抬升皮棉成本，对棉价形成支撑。",
        "source_weight": 0.7, "hours_ago": 3,
    },
    {
        "title": "【示例】伊朗两套甲醇装置计划停车检修 20 天",
        "content": "【示例】伊朗两套合计 380 万吨/年甲醇装置计划于下周停车检修，预计持续 20 天，市场担忧后期进口量下滑。",
        "varieties": ["MA"], "direction": "bullish", "strength": 4, "confidence": 0.86,
        "factor": "供给", "event_type": "装置检修", "horizon": "short",
        "summary": "伊朗装置停车检修，甲醇进口预期收缩。",
        "evidence": "伊朗两套合计 380 万吨/年甲醇装置计划于下周停车检修",
        "reasoning": "伊朗是中国甲醇主要进口来源，检修减少到港量，利多港口价格。",
        "source_weight": 0.85, "hours_ago": 2,
    },
    {
        "title": "【示例】华东甲醇港口库存连续三周累积",
        "content": "【示例】华东港口甲醇库存增至 92 万吨，连续三周累积，提货速度偏慢，贸易商出货压力增加。",
        "varieties": ["MA"], "direction": "bearish", "strength": 3, "confidence": 0.75,
        "factor": "库存", "event_type": "库存", "horizon": "medium",
        "summary": "华东港口库存连续累积，甲醇上方承压。",
        "evidence": "华东港口甲醇库存增至 92 万吨，连续三周累积",
        "reasoning": "库存累积反映需求偏弱与到港集中，压制现货价格。",
        "source_weight": 0.8, "hours_ago": 6,
    },
    {
        "title": "【示例】纯碱企业开工率回升至 88%，供应趋于宽松",
        "content": "【示例】隆众数据显示，本周纯碱行业开工率回升至 88%，环比提高 3 个百分点，部分检修装置恢复生产，供应趋于宽松。",
        "varieties": ["SA"], "direction": "bearish", "strength": 3, "confidence": 0.7,
        "factor": "供给", "event_type": "复产", "horizon": "short",
        "summary": "纯碱开工率回升，供应宽松压制盘面。",
        "evidence": "本周纯碱行业开工率回升至 88%，环比提高 3 个百分点",
        "reasoning": "检修装置恢复提高供应，短期利空纯碱。",
        "source_weight": 0.75, "hours_ago": 4,
    },
    {
        "title": "【示例】光伏玻璃日熔量下降，纯碱需求走弱",
        "content": "【示例】近期部分光伏玻璃产线冷修，行业日熔量环比下降约 1.2%，重碱刚需采购放缓，纯碱需求端支撑减弱。",
        "varieties": ["SA"], "direction": "bearish", "strength": 2, "confidence": 0.62,
        "factor": "需求", "event_type": "需求", "horizon": "medium",
        "summary": "光伏玻璃冷修，纯碱重碱需求走弱。",
        "evidence": "部分光伏玻璃产线冷修，行业日熔量环比下降约 1.2%",
        "reasoning": "光伏玻璃是重碱主要下游，日熔量下降削弱纯碱需求。",
        "source_weight": 0.7, "hours_ago": 8,
    },
    {
        "title": "【示例】沙河玻璃产销率提升，库存小幅去化",
        "content": "【示例】沙河地区玻璃产销率提升至 110%，厂家库存小幅去化，贸易商补库意愿增强，现货价格企稳。",
        "varieties": ["FG"], "direction": "bullish", "strength": 2, "confidence": 0.68,
        "factor": "库存", "event_type": "库存", "horizon": "short",
        "summary": "沙河产销率回升，玻璃库存去化，现货企稳。",
        "evidence": "沙河地区玻璃产销率提升至 110%，厂家库存小幅去化",
        "reasoning": "产销率回升显示下游补库，库存下降对价格有支撑。",
        "source_weight": 0.75, "hours_ago": 7,
    },
    {
        "title": "【示例】保交楼资金加快落地，竣工端预期改善",
        "content": "【示例】多地保交楼专项借款加快拨付，房企竣工节奏有望提速，市场对玻璃竣工端需求预期改善。",
        "varieties": ["FG"], "direction": "bullish", "strength": 3, "confidence": 0.66,
        "factor": "政策", "event_type": "政策", "horizon": "medium",
        "summary": "保交楼资金落地，玻璃竣工需求预期改善。",
        "evidence": "多地保交楼专项借款加快拨付，房企竣工节奏有望提速",
        "reasoning": "竣工端是浮法玻璃核心需求，政策推动改善中期需求预期。",
        "source_weight": 0.8, "hours_ago": 10,
    },
    {
        "title": "【示例】布伦特原油回落，甲醇成本支撑减弱",
        "content": "【示例】布伦特原油跌破 84 美元/桶，能化板块成本重心下移，甲醇期货跟随走弱，市场情绪偏谨慎。",
        "varieties": ["MA"], "direction": "bearish", "strength": 2, "confidence": 0.6,
        "factor": "成本", "event_type": "成本", "horizon": "short",
        "summary": "原油回落拖累能化成本，甲醇跟随走弱。",
        "evidence": "布伦特原油跌破 84 美元/桶，能化板块成本重心下移",
        "reasoning": "原油是能化成本锚，回落削弱甲醇成本支撑与市场情绪。",
        "source_weight": 0.7, "hours_ago": 9,
    },
]


def _hash(title: str, content: str) -> str:
    payload = re.sub(r"\s+", "", title) + "|" + re.sub(r"\s+", "", content)[:3000]
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


def seed() -> None:
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        if db.execute(select(Variety).limit(1)).scalars().first():
            return

        factors = {}
        for name, category, desc, color in FACTORS:
            f = Factor(name=name, category=category, description=desc, color=color)
            db.add(f)
            factors[name] = f
        db.flush()

        for item in ACTIVE_VARIETIES:
            v = Variety(
                code=item["code"], name=item["name"], sector=item["sector"],
                is_active=True, aliases=item["aliases"], keywords=item["keywords"],
                description=item["description"], sort_order=item["sort_order"],
            )
            db.add(v)
            db.flush()
            for fname, weight in item["factors"].items():
                db.add(VarietyFactor(
                    variety_id=v.id, factor_id=factors[fname].id, weight=weight,
                    keywords=item["factor_keywords"].get(fname, []),
                ))
        for i, (code, name, sector, aliases) in enumerate(PLACEHOLDER_VARIETIES, start=10):
            db.add(Variety(code=code, name=name, sector=sector, is_active=False,
                           aliases=aliases, keywords=aliases, sort_order=i))

        sources = {}
        for item in SOURCES:
            s = Source(**item, enabled=True)
            db.add(s)
            db.flush()
            sources[item["code"]] = s

        manual = sources["manual"]
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        for idx, sample in enumerate(SAMPLES):
            published = now - timedelta(hours=sample["hours_ago"], minutes=idx * 3)
            doc = RawDoc(
                source_id=manual.id,
                source_name="示例数据（手工录入）",
                source_weight=sample["source_weight"],
                url="",
                title=sample["title"],
                content=sample["content"],
                published_at=published,
                first_seen_at=published,
                content_hash=_hash(sample["title"], sample["content"]),
                matched_varieties=sample["varieties"],
                status="analyzed",
                is_manual=True,
            )
            db.add(doc)
            db.flush()
            analysis = Analysis(
                doc_id=doc.id,
                model="demo-seed",
                prompt_version="v1",
                status="analyzed",
                varieties=sample["varieties"],
                direction=sample["direction"],
                strength=sample["strength"],
                confidence=sample["confidence"],
                horizon=sample["horizon"],
                factor=sample["factor"],
                event_type=sample["event_type"],
                summary=sample["summary"],
                evidence=sample["evidence"],
                reasoning=sample["reasoning"],
                latency_ms=0,
                created_at=published,
                updated_at=published,
            )
            db.add(analysis)
            db.flush()
            for code in sample["varieties"]:
                s = compute_score(
                    sample["direction"], sample["strength"], sample["confidence"],
                    sample["source_weight"], published, sample["horizon"], novelty=1.0,
                )
                db.add(Score(
                    analysis_id=analysis.id, doc_id=doc.id, variety_code=code,
                    direction=sample["direction"], score=s, importance=abs(s),
                    confidence=sample["confidence"], factor=sample["factor"],
                ))
        db.commit()
        print(f"[seed] 已初始化 {len(ACTIVE_VARIETIES)} 个活跃品种、{len(SOURCES)} 个数据源、{len(SAMPLES)} 条示例资讯")
