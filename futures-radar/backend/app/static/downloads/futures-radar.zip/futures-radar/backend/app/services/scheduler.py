from __future__ import annotations

import asyncio
import traceback

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from ..config import settings
from ..collectors.base import list_collectors
from .digest import today_str, upsert_digest
from .market import collect_fred_brent, collect_oil

scheduler = AsyncIOScheduler(timezone="Asia/Shanghai")


async def run_collect(code: str) -> dict:
    cls = list_collectors().get(code)
    if not cls:
        return {"ok": False, "error": f"未实现的采集器：{code}"}
    return await cls().collect()


async def run_task(task: str) -> dict:
    if task in ("jin10_flash", "sina_rss", "czce_announce"):
        return await run_collect(task)
    if task == "oil":
        return await collect_oil()
    if task == "fred":
        return await collect_fred_brent()
    if task == "digest":
        result = upsert_digest(today_str())
        return {"ok": True, "date": result["date"]}
    return {"ok": False, "error": f"未知任务：{task}"}


async def _safe(coro, label: str) -> None:
    try:
        await coro
    except Exception:  # noqa: BLE001
        print(f"[scheduler] {label} 执行失败")
        traceback.print_exc()


async def job_oil() -> None:
    await _safe(collect_oil(), "oil")


async def job_jin10() -> None:
    await _safe(run_collect("jin10_flash"), "jin10")


async def job_rss() -> None:
    await _safe(run_collect("sina_rss"), "rss")


async def job_czce() -> None:
    await _safe(run_collect("czce_announce"), "czce")


async def job_fred() -> None:
    await _safe(collect_fred_brent(), "fred")


async def job_digest() -> None:
    await _safe(_digest_job(), "digest")


def start_scheduler() -> AsyncIOScheduler:
    if not settings.enable_scheduler:
        return scheduler

    scheduler.add_job(job_oil, "interval", seconds=settings.interval_oil,
                      id="oil", max_instances=1, coalesce=True)
    scheduler.add_job(job_jin10, "interval", seconds=settings.interval_jin10,
                      id="jin10", max_instances=1, coalesce=True)
    scheduler.add_job(job_rss, "interval", seconds=settings.interval_rss,
                      id="rss", max_instances=1, coalesce=True)
    scheduler.add_job(job_czce, "interval", seconds=settings.interval_czce,
                      id="czce", max_instances=1, coalesce=True)
    scheduler.add_job(job_fred, "interval", seconds=settings.interval_fred,
                      id="fred", max_instances=1, coalesce=True)
    scheduler.add_job(job_digest, "interval", seconds=settings.interval_digest,
                      id="digest", max_instances=1, coalesce=True)

    if not scheduler.running:
        scheduler.start()
    return scheduler


async def _digest_job() -> None:
    await asyncio.to_thread(upsert_digest, today_str())


def shutdown_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
