<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { api } from '../api'
import { live } from '../store'
import OilTicker from '../components/OilTicker.vue'
import SentimentBar from '../components/SentimentBar.vue'
import ArticleCard from '../components/ArticleCard.vue'
import ArticleDrawer from '../components/ArticleDrawer.vue'

const data = ref(null)
const loading = ref(true)
const drawerId = ref(null)
let timer = null

async function load() {
  try {
    data.value = await api.dashboard()
  } finally {
    loading.value = false
  }
}

onMounted(load)
watch(() => live.version, () => {
  clearTimeout(timer)
  timer = setTimeout(load, 600)
})

const stats = computed(() => data.value?.stats || {})
const oil = computed(() => data.value?.oil || [])
const varieties = computed(() => data.value?.varieties || [])
const latest = computed(() => data.value?.latest || [])
const sourceInfo = computed(() => {
  const list = (data.value?.sources || []).filter((s) => s.code !== 'manual')
  return { ok: list.filter((s) => s.status === 'ok').length, total: list.length }
})
</script>

<template>
  <div class="container">
    <div class="page-head">
      <div>
        <h1>今日总览</h1>
        <div class="sub">{{ data?.date }} · {{ data?.mode === 'deepseek' ? 'DeepSeek 精判' : '免费模式 · 规则引擎' }}</div>
      </div>
      <button class="btn btn-sm" @click="load">刷新</button>
    </div>

    <OilTicker :quotes="oil" />

    <div class="card summary-strip">
      <div class="sum-item"><span>今日入库</span><b>{{ stats.docs_today ?? 0 }}</b></div>
      <div class="sum-item"><span>关联品种</span><b>{{ stats.matched_today ?? 0 }}</b></div>
      <div class="sum-item"><span>已研判</span><b class="val-brand">{{ stats.analyzed_today ?? 0 }}</b></div>
      <div class="sum-item"><span>待研判</span><b :class="{ warn: (stats.pending ?? 0) > 0 }">{{ stats.pending ?? 0 }}</b></div>
      <div class="sum-item"><span>数据源</span><b>{{ sourceInfo.ok }}/{{ sourceInfo.total }}</b></div>
    </div>

    <div class="section-head">
      <h2>品种多空速览</h2>
      <span class="hint">点击品种查看详情</span>
    </div>
    <div class="variety-grid">
      <router-link v-for="v in varieties" :key="v.code" :to="`/variety/${v.code}`" class="card variety-card">
        <div class="vc-head">
          <h4>{{ v.name }}</h4>
          <span class="code">{{ v.code }}</span>
        </div>
        <SentimentBar :value="v.sentiment" />
        <div class="vc-counts">
          <span class="up">利多 {{ v.bullish_count }}</span>
          <span class="down">利空 {{ v.bearish_count }}</span>
          <span class="muted">{{ v.count }} 条</span>
        </div>
      </router-link>
    </div>

    <div class="section-head">
      <h2>最新资讯</h2>
      <router-link to="/feed" class="hint" style="color:var(--brand)">查看全部 →</router-link>
    </div>
    <section class="card">
      <div class="feed-list">
        <ArticleCard v-for="a in latest" :key="a.id" :article="a" @open="drawerId = $event" />
        <div v-if="!latest.length && !loading" class="empty">暂无已关联资讯，可先手工录入一条试试</div>
      </div>
    </section>

    <div class="footer-line">
      <span>数据源 {{ sourceInfo.ok }}/{{ sourceInfo.total }} 正常 · 郑商所官网有反爬</span>
      <router-link to="/sources">采集日志 →</router-link>
      <span class="disclaimer">仅用于信息整理，不构成投资建议</span>
    </div>
  </div>

  <ArticleDrawer v-if="drawerId" :doc-id="drawerId" @close="drawerId = null" />
</template>
